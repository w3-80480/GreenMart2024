const mysql = require("mysql")

const connection = mysql.createConnection({
  host: "localhost",
  user: "W3_80270_vaishnavi",
  password: "vaishnavi",
  database: "db_GreenMart",
  multipleStatements: true
})

connection.connect()

module.exports = connection
